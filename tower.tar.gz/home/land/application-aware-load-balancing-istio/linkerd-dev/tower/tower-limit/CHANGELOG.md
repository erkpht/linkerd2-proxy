# 0.1.1 (October 11, 2019)

- Added `tracing` events for when requests are limited

# 0.1.0 (April 26, 2019)

- Initial release
