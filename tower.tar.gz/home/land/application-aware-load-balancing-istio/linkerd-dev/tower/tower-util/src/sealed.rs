pub trait Sealed<T> {}
