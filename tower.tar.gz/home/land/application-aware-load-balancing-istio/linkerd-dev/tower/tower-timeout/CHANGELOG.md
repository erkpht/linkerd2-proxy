# 0.1.1 (July 30th, 2019)

- Add `Elapsed::new`

# 0.1.0 (April 26, 2019)

- Initial release
