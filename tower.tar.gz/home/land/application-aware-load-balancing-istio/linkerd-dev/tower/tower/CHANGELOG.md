# 0.1.1 (July 19, 2019)

- Add `ServiceBuilder::into_inner`

# 0.1.0 (April 26, 2019)

- Initial release
