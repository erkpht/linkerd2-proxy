# 0.1.2 (October 11, 2019)

- Bump `tokio-sync` to `v0.1.3`

# 0.1.1 (July 19, 2019)

- Add `tracing` support

# 0.1.0 (April 26, 2019)

- Initial release
